export default {
  name: 'ping',
  description: 'Mide la latencia',
  async execute({ client, message, config }) {
    const sent = await message.channel.send('🏓 Pong...');
    const latency = sent.createdTimestamp - message.createdTimestamp;
    const api = Math.round(client.ws.ping);

    await sent.edit({
      embeds: [
        {
          color: parseInt((config.embedColor || '#5865F2').replace('#', ''), 16),
          title: '🏓 Pong!',
          fields: [
            { name: 'Latencia del bot', value: `\`${latency}ms\``, inline: true },
            { name: 'Latencia API', value: `\`${api}ms\``, inline: true }
          ],
          timestamp: new Date().toISOString()
        }
      ],
      content: ''
    });
  }
};