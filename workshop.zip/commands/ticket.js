import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';

export default {
  name: 'ticket',
  description: 'Envía el panel para abrir tickets',
  async execute({ message, config }) {
    // Permitir solo a staff (si config.staffRoleId está definido)
    if (config.staffRoleId && !message.member.roles.cache.has(config.staffRoleId)) {
      return message.reply('❌ No tienes permisos para usar este comando.');
    }

    const fila = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('ticket_roles')
        .setLabel('Roles especiales')
        .setEmoji('🎯')
        .setStyle(ButtonStyle.Primary),

      new ButtonBuilder()
        .setCustomId('ticket_soporte')
        .setLabel('Soporte')
        .setEmoji('🛠️')
        .setStyle(ButtonStyle.Success),

      new ButtonBuilder()
        .setCustomId('ticket_sugerencias')
        .setLabel('Sugerencias')
        .setEmoji('💡')
        .setStyle(ButtonStyle.Secondary)
    );

    await message.channel.send({
      embeds: [
        {
          color: parseInt((config.embedColor || '#5865F2').replace('#', ''), 16),
          title: '🎫 Centro de soporte',
          description:
            'Elige una opción para abrir tu ticket.\n' +
            'Un miembro del equipo te atenderá lo antes posible.',
          footer: { text: 'Recuerda no compartir datos sensibles.' },
          timestamp: new Date().toISOString()
        }
      ],
      components: [fila]
    });
  }
};