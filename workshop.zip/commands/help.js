export default {
  name: 'help',
  description: 'Muestra la lista de comandos',
  async execute({ message, config }) {
    const prefix = config.prefix || '!';
    await message.channel.send({
      embeds: [
        {
          color: parseInt((config.embedColor || '#5865F2').replace('#', ''), 16),
          title: '📚 Ayuda del bot',
          description:
            `Aquí tienes los comandos disponibles (prefijo **${prefix}**):\n\n` +
            `• \`${prefix}ping\` — Comprueba la latencia\n` +
            `• \`${prefix}ticket\` — Muestra el panel para abrir tickets\n` +
            `• \`${prefix}help\` — Ves este mensaje\n`,
          footer: { text: 'Bot listo para ayudarte' },
          timestamp: new Date().toISOString()
        }
      ]
    });
  }
};