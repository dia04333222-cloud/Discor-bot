export default {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`✅ Conectado como ${client.user.tag}`);
    try {
      await client.user.setPresence({
        activities: [{ name: '¡Escribe !help', type: 0 }],
        status: 'online'
      });
    } catch {}
  }
};