export default {
  name: 'guildMemberAdd',
  async execute(client, member, config) {
    try {
      // Autorole (opcional)
      if (config.autoroleId) {
        const rol = member.guild.roles.cache.get(config.autoroleId);
        if (rol) await member.roles.add(rol).catch(() => {});
      }

      // Canal de bienvenida
      const canal = config.welcomeChannelId
        ? member.guild.channels.cache.get(config.welcomeChannelId)
        : null;
      if (!canal) return;

      await canal.send({
        content: `<@${member.id}>`,
        embeds: [
          {
            color: parseInt((config.embedColor || '#5865F2').replace('#', ''), 16),
            title: '👋 ¡Bienvenido!',
            description:
              `Nos alegra tenerte aquí, **${member.user.username}**.\n` +
              `Lee las reglas y disfruta del servidor.`,
            thumbnail: { url: member.user.displayAvatarURL({ size: 256 }) },
            footer: { text: `Miembro #${member.guild.memberCount}` },
            timestamp: new Date().toISOString()
          }
        ]
      });
    } catch (err) {
      console.error('Error en bienvenida:', err);
    }
  }
};