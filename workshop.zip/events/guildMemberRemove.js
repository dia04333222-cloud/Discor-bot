export default {
  name: 'guildMemberRemove',
  async execute(client, member, config) {
    try {
      const canal = config.leaveChannelId
        ? member.guild.channels.cache.get(config.leaveChannelId)
        : null;
      if (!canal) return;

      const nombre = member.user?.username || 'Un usuario';
      await canal.send({
        embeds: [
          {
            color: parseInt((config.embedColor || '#5865F2').replace('#', ''), 16),
            title: '👋 Despedida',
            description: `**${nombre}** ha salido del servidor. ¡Suerte en tu camino!`,
            timestamp: new Date().toISOString()
          }
        ]
      });
    } catch (err) {
      console.error('Error en despedida:', err);
    }
  }
};