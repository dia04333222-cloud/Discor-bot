import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  Client,
  Collection,
  GatewayIntentBits,
  Partials,
  Events,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField
} from 'discord.js';
import config from './config.json' assert { type: 'json' };

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Token desde variable de entorno (Koyeb → Variables → TOKEN)
const token = process.env.TOKEN;
if (!token) {
  console.error('❌ No has definido la variable de entorno TOKEN.');
  process.exit(1);
}

// Cliente con intents necesarios
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,            // info de servidores
    GatewayIntentBits.GuildMessages,     // mensajes en canales
    GatewayIntentBits.MessageContent,    // contenido de mensajes (para prefijo y enlaces)
    GatewayIntentBits.GuildMembers       // para bienvenidas/despedidas y autorole
  ],
  partials: [Partials.User, Partials.GuildMember]
});

client.commands = new Collection();

// Carga de comandos
async function loadCommands() {
  const commandsPath = path.join(__dirname, 'commands');
  if (!fs.existsSync(commandsPath)) return;

  const files = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'));
  for (const file of files) {
    const mod = await import(`./commands/${file}`);
    const cmd = mod?.default;
    if (cmd?.name && typeof cmd.execute === 'function') {
      client.commands.set(cmd.name, cmd);
    }
  }
}

// Carga de eventos
async function loadEvents() {
  const eventsPath = path.join(__dirname, 'events');
  if (!fs.existsSync(eventsPath)) return;

  const files = fs.readdirSync(eventsPath).filter(f => f.endsWith('.js'));
  for (const file of files) {
    const { default: event } = await import(`./events/${file}`);
    if (!event?.name || typeof event.execute !== 'function') continue;
    if (event.once) client.once(event.name, (...args) => event.execute(client, ...args, config));
    else client.on(event.name, (...args) => event.execute(client, ...args, config));
  }
}

// Sistema de comandos con prefijo "!"
client.on(Events.MessageCreate, async (message) => {
  try {
    if (!message.guild || message.author.bot) return;
    const prefix = config.prefix || '!';

    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/\s+/);
    const commandName = (args.shift() || '').toLowerCase();

    const command = client.commands.get(commandName);
    if (!command) return;

    await command.execute({ client, message, args, config });
  } catch (err) {
    console.error('Error ejecutando comando:', err);
    if (message?.reply) message.reply('❌ Ocurrió un error al ejecutar el comando.');
  }
});

// Detector de enlaces de YouTube -> avisa en canal de salida y menciona rol
client.on(Events.MessageCreate, async (message) => {
  try {
    if (!message.guild || message.author.bot) return;
    const { inputChannelId, outputChannelId, notifyRoleId } = config;
    if (!inputChannelId || !outputChannelId || !notifyRoleId) return;
    if (message.channel.id !== inputChannelId) return;

    const match = message.content.match(
      /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/
    );
    if (!match) return;

    const videoURL = match[0];
    const out = await client.channels.fetch(outputChannelId);

    await out.send({
      content: `🔔 **Aviso para <@&${notifyRoleId}>**`,
      embeds: [
        {
          color: parseInt((config.embedColor || '#5865F2').replace('#', ''), 16),
          title: '🎥 ¡Nuevo video en YouTube!',
          description: `➡️ **Míralo aquí:** ${videoURL}\n\nSi te gusta, deja tu **like** y un **comentario** 🙌`,
          footer: { text: 'Aviso automático de novedades' },
          timestamp: new Date().toISOString()
        }
      ]
    });
  } catch (err) {
    console.error('Error en detector de YouTube:', err);
  }
});

// Interacciones de botones (tickets)
client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (!interaction.isButton()) return;

    const { staffRoleId } = config;
    const motivoId = interaction.customId; // 'ticket_roles' | 'ticket_soporte' | 'ticket_sugerencias'

    // Crear el canal del ticket
    const nombre = `ticket-${interaction.user.username}`.slice(0, 90);

    const overwrites = [
      // Ocultar a todos
      { id: interaction.guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
      // Usuario
      { id: interaction.user.id, allow: [
        PermissionsBitField.Flags.ViewChannel,
        PermissionsBitField.Flags.SendMessages,
        PermissionsBitField.Flags.ReadMessageHistory,
        PermissionsBitField.Flags.AttachFiles
      ] }
    ];

    if (staffRoleId) {
      overwrites.push({
        id: staffRoleId,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.ReadMessageHistory,
          PermissionsBitField.Flags.ManageMessages
        ]
      });
    }

    const canal = await interaction.guild.channels.create({
      name: nombre,
      type: ChannelType.GuildText,
      permissionOverwrites: overwrites,
      reason: `Ticket abierto por ${interaction.user.tag} (${motivoId})`
    });

    const textos = {
      ticket_roles: {
        titulo: '🎯 Solicitud de roles especiales',
        cuerpo: `Hola <@${interaction.user.id}>. Indica qué **rol** necesitas y por qué.\nUn miembro de <@&${staffRoleId}> te atenderá en breve.`
      },
      ticket_soporte: {
        titulo: '🛠️ Atención de soporte',
        cuerpo: `Hola <@${interaction.user.id}>. Describe tu problema con detalle (pasos, capturas, etc.)\n<@&${staffRoleId}> te ayudará cuanto antes.`
      },
      ticket_sugerencias: {
        titulo: '💡 Sugerencias',
        cuerpo: `Hola <@${interaction.user.id}>. Cuéntanos tu **idea o mejora**.\n<@&${staffRoleId}> la revisará y comentará contigo.`
      }
    };

    const info = textos[motivoId] || {
      titulo: '🎫 Ticket abierto',
      cuerpo: `Hola <@${interaction.user.id}>. Describe tu consulta.\n<@&${staffRoleId}> te atenderá enseguida.`
    };

    await canal.send({
      content: staffRoleId ? `<@&${staffRoleId}>` : null,
      embeds: [
        {
          color: parseInt((config.embedColor || '#5865F2').replace('#', ''), 16),
          title: info.titulo,
          description: info.cuerpo,
          footer: { text: 'Usa el botón "Cerrar ticket" cuando termines.' },
          timestamp: new Date().toISOString()
        }
      ],
      components: [
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('ticket_cerrar')
            .setLabel('Cerrar ticket')
            .setEmoji('🔒')
            .setStyle(ButtonStyle.Danger)
        )
      ]
    });

    await interaction.reply({ content: `✅ Ticket creado: ${canal}`, ephemeral: true });
  } catch (err) {
    console.error('Error creando ticket:', err);
    if (interaction?.replied === false) {
      await interaction.reply({ content: '❌ No se pudo crear el ticket.', ephemeral: true });
    }
  }
});

// Cerrar ticket con botón
client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (!interaction.isButton()) return;
    if (interaction.customId !== 'ticket_cerrar') return;

    await interaction.reply({ content: '🔒 Cerrando ticket en 3 segundos…', ephemeral: true });
    setTimeout(() => {
      interaction.channel?.delete('Ticket cerrado por botón').catch(() => {});
    }, 3000);
  } catch (err) {
    console.error('Error cerrando ticket:', err);
  }
});

// Inicio
(async () => {
  await loadCommands();
  await loadEvents();
  await client.login(token);
})();